<?php

namespace App\Http\Controllers;
use App\Models\companymodel;
use App\Models\employeemodel;
use Illuminate\Support\Facades\Storage;

use Illuminate\Http\Request;

class CompanyController extends Controller
{
    
    public function companyformfun()
    {

        return view('companies.index');   
    }

    public function companystorefun(Request $request)
{
    $company = new CompanyModel();
    $company->name = $request->input('name');
    $company->email = $request->input('email');
    $company->website = $request->input('website');
   
    // Handle the uploaded image
    if($request->hasFile('logo'))
    {
        $file=$request->file('logo');
        $extension=$file->getClientOriginalExtension();
        $filename=time().'.'.$extension;
        $file->storeAs('public/company', $filename);
        $company->logo=$filename;
    }
    $company->save();
    return redirect()->back()->with('status','Company Added Successfully!!!');


    $company->save();

echo"<h1>......Data Send Successfully.....</h1>";
}


    public function companyshowfun(Request $companies)
    {
        
       // Fetch all companies from the database
       $companies = companymodel::all();
       return view('companies.company_view', compact('companies'));
    }

//Delete the company record 

   
// public function companyDeletefun($id)
// {
//     $company = companymodel::find($id);

//     // Delete the company
//     $company->delete();

//     return view('companies.company_view')->with('success', 'Company deleted successfully.');
// }

public function companyDeletefun($id)
{
    $company =companymodel::where('id',$id)->first();

    if ($company != null) {
        $company->delete();
        return view('companies.index');
    }
    return view('companies.index');
} 

public function editshowfun($id)
    {
        $data= companymodel::find($id);
        return view('companies.edit',['data'=>$data]);
    }

    public function updatecompanyfun(Request $req)
    {
        $data= companymodel::find($req->id);
        $data->name=$req->name;
        $data->email=$req->email;
        if($req->hasFile('logo'))
    {
        $file=$req->file('logo');
        $extension=$file->getClientOriginalExtension();
        $filename=time().'.'.$extension;
        $file->storeAs('public/company', $filename);
        $data->logo=$filename;
    }
        $data->website=$req->website;
        $data->save();
        return view('companies.index',['data'=>$data]);
    }

    
}
