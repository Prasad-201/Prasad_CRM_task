<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\studentmodel; 

class StudentController extends Controller
{
    public function studentformfun()
    {
        $students=studentmodel::all();
        return view('student.studentIndex',compact('students'));
    }
    public function studentcreatefun()
    {
        return view('student.createStudent');
    }

    public function studentstorefun(Request $request)
    {
        $student=new studentmodel();

        $student->name=$request->input('name');
        $student->email=$request->input('email');
        // $student->image=$request->input('image');
        $student->course=$request->input('course');
            if($request->hasFile('image'))
            {
                $file=$request->file('image');
                $extension=$file->getClientOriginalExtension();
                $filename=time().'.'.$extension;
                $file->storeAs('public/company_img', $filename);
                $student->image=$filename;
            }
            $student->save();
            return redirect()->back()->with('status','Student Added Successfully!!!');
    }

}
