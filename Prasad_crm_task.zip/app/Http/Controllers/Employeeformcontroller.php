<?php

namespace App\Http\Controllers;
use App\Models\companymodel;
use App\Models\employeemodel;
use Illuminate\Http\Request;


class Employeeformcontroller extends Controller
{
    public function employeeformfun()
    {
        return view('employees.index');      
    }

    // employeecretefun
    public function  employeestorefun(Request $request)
    {
       
        $employee=new employeemodel();
        $employee->fname=$request->input('fname');
        $employee->lname=$request->input('lname');
        $employee->company=$request->input('company');
        $employee->pnumber=$request->input('pnumber');
        $employee->email=$request->input('email');
        

        // Handle the uploaded image
        if($request->hasFile('pic'))
            {
                $file=$request->file('pic');
                $extension=$file->getClientOriginalExtension();
                $filename=time().'.'.$extension;
                $file->storeAs('public/employee_img', $filename);
                $employee->pic=$filename;
            }
            $employee->save();
            return redirect()->back()->with('status','Employee Added Successfully!!!');
    

        $employee->save();

        echo"<h1>......Data Send Successfully.....</h1>";
    }


   
        // Validate the form data
        


    // public function employeeshow($id)
    // {
    //     $employee = employeemodel::findOrFail($id);
    //     return view('employees.show', compact('employee'));
    // }

    // employeestorefun  , showemployeefun
    public function employeecreatefun()
    {
        $employees = employeemodel::all(); // Fetch all employees from the database
        return view('employees.employee_view', compact('employees'));
    }

    
    public function EmpEditShowfun($id)
    {
        $data= companymodel::find($id);
        return view('employees.editemp',['data'=>$data]);
    }

   
   public function EmpUpdateCompanyfun(Request $req)
{
    $data= companymodel::find($req->id);
    $data->fname=$req->fname;
    $data->lname=$req->lname;
    $data->company=$req->company;
    $data->pnumber=$req->pnumber;
    $data->email=$req->email;

    // Check if an image is uploaded
    if($req->hasFile('pic'))
    {
        $file = $req->file('pic');
        $extension = $file->getClientOriginalExtension();
        $filename = time().'.'.$extension;
        $file->storeAs('public/employee_img', $filename);
        $data->pic = $filename;
    }

    $data->save();
    return view('employees.index');   
}

public function EmployeeDeletefun($id)
{
    $employee =employeemodel::where('id',$id)->first();

    if ($employee != null) {
        $employee->delete();
      return view('employees.index');
    }
    return view('employees.index');
} 

}

