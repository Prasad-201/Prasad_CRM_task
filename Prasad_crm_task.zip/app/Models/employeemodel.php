<?php

namespace App\Models;
use App\Models\companymodel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class employeemodel extends Model
{
    use HasFactory;
    protected $table="employees";			
    protected $fillabel=['fname','lname','email','pic','pnumber','company'];
}
