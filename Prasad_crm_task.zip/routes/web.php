<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Employeeformcontroller;
use League\CommonMark\Extension\SmartPunct\DashParser;

use App\Http\Controllers\StudentController;
//student controller :
Route::get('/student',[StudentController::class,'studentformfun']);
Route::get('/add-student',[StudentController::class,'studentcreatefun']);
Route::post('/add-student',[StudentController::class,'studentstorefun']);


Route::get('/', [DashboardController::class, 'dashboardfun']);

// Company
Route::get('/company', [CompanyController::class, 'companyformfun']);
Route::post('/add-company', [CompanyController::class, 'companystorefun']);
Route::get('/add-company', [CompanyController::class, 'companyshowfun']);
//Company-Delete
Route::get('/delete_company/{id}', [CompanyController::class, 'companyDeletefun']);
Route::get('/edit_company/{id}', [CompanyController::class, 'editshowfun']);
Route::post('/edit_company', [CompanyController::class, 'updatecompanyfun']);




// Employees
Route::get('/employee', [Employeeformcontroller::class, 'employeeformfun']);
Route::post('/add-employee', [Employeeformcontroller::class, 'employeestorefun']);
Route::get('/add-employee', [Employeeformcontroller::class,'employeecreatefun']);

// delete Employee
Route::get('/delete_employee/{id}', [Employeeformcontroller::class, 'EmployeeDeletefun']);

// return redirect()->back()->with('success', 'Form data submitted successfully.');
//update Employee
Route::get('/edit_employee/{id}', [Employeeformcontroller::class, 'EmpEditShowfun']);
Route::post('/edit_employee', [Employeeformcontroller::class, 'EmpUpdateCompanyfun']);
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
