<!DOCTYPE html>
<html>
<head>
  <title>Add New Employee</title>
  <!-- Include Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="companyindex.php">
  <style>
    /* Add any additional custom styles here if needed */
    body {
      margin: 0px;
      padding-top: 70px; /* Add padding to body to avoid content overlapping with the fixed navbar */
    }

    /* Customize the navbar appearance */
    .navbar {
      background-color: #333; /* Change the background color of the navbar */
      border-bottom: 3px solid #e50914; /* Add a bottom border with a red color */
    }

    .navbar-brand {
      color: #e50914; /* Change the color of the navbar brand text */
      font-weight: bold; /* Add bold font weight to the navbar brand text */
    }

    .navbar-nav .nav-link {
      color: #fff; /* Change the color of the navbar links */
    }

    .navbar-nav .nav-link:hover {
      color: #e50914; /* Change the color of the navbar links on hover */
    }

    .dropdown-menu {
      background-color: #333; /* Change the background color of the dropdown menu */
    }

    .dropdown-item {
      color: #fff; /* Change the color of the dropdown items */
    }

    .dropdown-item:hover {
      background-color: #e50914; /* Change the background color of the dropdown items on hover */
    }
  </style>
</head>
<body>


<nav class="navbar navbar-expand-sm fixed-top">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Quantum IT Innovation</a>

  <!-- Links -->
  <ul class="navbar-nav">
    
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Menu
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/company">Create Company</a>
        <a class="dropdown-item" href="/add-company">View Company</a>
        <a class="dropdown-item" href="/employee">Create Employees</a>
        <a class="dropdown-item" href="/add-employee">View Employees</a>
      </div>
    </li>
  </ul>
</nav>
<br>

  
<div class="container">
 
</div>
 


<div class="container">
  <div class="row">
  <div class="col-md-12">
      <div class="col-md-12">
          <div class="col-md-12">

              <?php if(session('status')): ?>
                  <h6 class="alert alert-success"><?php echo e(session('status')); ?></h6>
              <?php endif; ?>

          </h4>
          
          <div class="card-body">
            
              <div class="container">
                  <h2>Add a New Employee</h2>
  <form action="<?php echo e('add-employee'); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label for="fname">First Name <span style="color: red;">*</span></label>
        <input type="text" class="form-control" id="fname" name="fname" required>
      </div>

    <div class="form-group">
      <label for="lname">Last Name <span style="color: red;">*</span></label>
      <input type="text" class="form-control" id="lname" name="lname" required>
    </div>

    

    <div class="form-group">
      <label for="company">Company <span style="color: red;">*</span></label>
      <input type="text" class="form-control" id="company" name="company" required>
    </div>

    <div class="form-group">
      <label for="email">Email <span style="color: red;">*</span></label>
      <input type="email" class="form-control" id="email" name="email" required>
    </div>

    <div class="form-group">
      <label for="pnumber">Phone Number <span style="color: red;">*</span></label>
      <input type="text" class="form-control" id="pnumber" name="pnumber" required>
    </div>

    <div class="form-group">
      <label for="pic">Profile Picture <span style="color: red;">*</span></label>
      <input type="file" class="form-control" id="pic" name="pic" accept="image/*" required>
    </div>

    <div class="form-group">
      <button type="submit" class="btn btn-primary">Add Employee</button>
      <a href="<?php echo e(url('add-employee')); ?>" class="btn btn-success float-end">View Employee</a>
    </div>
  </form>
</div>

<!-- Include Bootstrap JS and jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

  

  


              <?php /**PATH C:\xampp_new\htdocs\quantum_crm_app\quantum_crm_app\resources\views/employees/index.blade.php ENDPATH**/ ?>