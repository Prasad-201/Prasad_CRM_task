<!-- resources/views/companies/delete.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Delete Company</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Delete Company</h2>
        <p>Are you sure you want to delete this company record ?</p>
        <form action="<?php echo e('/delete_company/{id}'); ?>" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
            
        </form>
    </div>

    <!-- Include Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp_new\htdocs\quantum_crm_app\quantum_crm_app\resources\views/companies/company_delete.blade.php ENDPATH**/ ?>