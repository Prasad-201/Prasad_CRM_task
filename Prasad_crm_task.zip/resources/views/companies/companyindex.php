<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<style>
    /* Add any additional custom styles here if needed */
    body {
      margin: 0px;
      padding-top: 70px; /* Add padding to body to avoid content overlapping with the fixed navbar */
    }

    /* Customize the navbar appearance */
    .navbar {
      background-color: #333; /* Change the background color of the navbar */
      border-bottom: 3px solid #e50914; /* Add a bottom border with a red color */
    }

    .navbar-brand {
      color: #e50914; /* Change the color of the navbar brand text */
      font-weight: bold; /* Add bold font weight to the navbar brand text */
    }

    .navbar-nav .nav-link {
      color: #fff; /* Change the color of the navbar links */
    }

    .navbar-nav .nav-link:hover {
      color: #e50914; /* Change the color of the navbar links on hover */
    }

    .dropdown-menu {
      background-color: #333; /* Change the background color of the dropdown menu */
    }

    .dropdown-item {
      color: #fff; /* Change the color of the dropdown items */
    }

    .dropdown-item:hover {
      background-color: #e50914; /* Change the background color of the dropdown items on hover */
    }
  </style>
</head>
<body>

{{-- menubar --}}
<nav class="navbar navbar-expand-sm fixed-top">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Quantum IT Innovation</a>

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#">Create Company</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">View Companies</a>
    </li>

    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Menu
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/company">Create Company</a>
        <a class="dropdown-item" href="/add-company">View Company</a>
        <a class="dropdown-item" href="/employee">Create Employees</a>
        <a class="dropdown-item" href="/add-employee">View Employees</a>
      </div>
    </li>
  </ul>
</nav>
<br>

  
<div class="container">
  <h3>Navbar With Dropdown</h3>
  <p>This example adds a dropdown menu in the navbar.</p>
</div>

</body>
</html>
