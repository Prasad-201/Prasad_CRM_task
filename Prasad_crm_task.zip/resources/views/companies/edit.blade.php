<!DOCTYPE html>
<html>
<head>
  <title>Add a New Company</title>
  <!-- Include Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="companyindex.php">
  <style>
    /* Add any additional custom styles here if needed */
    body {
      *margin: 0px;
    }
  </style>
</head>
<body>

{{-- menubar --}}
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Quantum IT Innovation</a>

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#">Create Comapny</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">View Comapnies</a>
    </li>

    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Menu
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/company">Create Company</a>
        <a class="dropdown-item" href="/add-company">View Company</a>
        <a class="dropdown-item" href="/employee">Create Employees</a>
        <a class="dropdown-item" href="/add-employee">View Employees</a>
      </div>
    </li>
  </ul>
</nav>
<br>
{{-- ****************************************Part-2{Form}******************************************************** --}}

<div class="container">
  <div class="row">
  <div class="col-md-12">
      <div class="col-md-12">
          <div class="col-md-12">

              @if(session('status'))
                  <h6 class="alert alert-success">{{session('status')}}</h6>
              @endif     
          
          </h4>
          
      <div class="card-body">
            
      <div class="container">
      <h2>Update Company Record</h2>
      <form action="{{'/edit_company'}}" method="post" enctype="multipart/form-data">
        @csrf
    {{-- <form action="/companies/store" method="get" enctype="multipart/form-data"> --}}
        <input type="hidden" class="form-control" id="id" value="{{$data['id']}}" name="id" required>
      <div class="form-group">
        <label for="name">Company Name :<span style="color: red;">*</span></label>
        <input type="text" class="form-control" id="name" value="{{$data['name']}}" name="name" required>
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email" value="{{$data['email']}}">
      </div>
      <div class="form-group">
        <label>Logo:<span style="color: red;">*</span></label>
        <div class="custom-file">
          <input type="file" class="custom-file-input" id="logo" name="logo" required>
          <label class="custom-file-label" for="logo">Choose Logo (Minimum size: 100x100)</label value="{{$data['logo']}}">
        </div>
      </div>
      <div class="form-group">
        <label for="website">Website:</label>
        <input type="text" class="form-control" id="website" name="website" value="{{$data['website']}}">
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary">Update Company</button>
        {{-- <a href="{{url('add-company')}}" class="btn btn-success float-end">View Company</a> --}}
      </div>
    </form>
  </div>

</div>
</div>
</div>           
</div>
</div>
</div>

  <!-- Include Bootstrap JS and jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


  
{{-- ****************************************Part-2{Form}******************************************************** --}}
