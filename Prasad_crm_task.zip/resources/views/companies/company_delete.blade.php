<!-- resources/views/companies/delete.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Delete Company</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h2>Delete Company</h2>
        <p>Are you sure you want to delete this company record ?</p>
        <form action="{{'/delete_company/{id}'}}" method="post">
            @csrf
            <button type="submit" class="btn btn-danger">Delete</button>
            {{-- <a href="{{ route('company_view') }}" class="btn btn-secondary">Cancel</a> --}}
        </form>
    </div>

    <!-- Include Bootstrap JS and jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
