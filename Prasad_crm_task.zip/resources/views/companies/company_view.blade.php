<!DOCTYPE html>
<html>
<head>
  <title>View Company</title>
  <!-- Include Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="companyindex.php">
  <style>
    /* Add any additional custom styles here if needed */
    body {
      margin: 0px;
      padding-top: 70px; /* Add padding to body to avoid content overlapping with the fixed navbar */
    }

    /* Customize the navbar appearance */
    .navbar {
      background-color: #333; /* Change the background color of the navbar */
      border-bottom: 3px solid #e50914; /* Add a bottom border with a red color */
    }

    .navbar-brand {
      color: #e50914; /* Change the color of the navbar brand text */
      font-weight: bold; /* Add bold font weight to the navbar brand text */
    }

    .navbar-nav .nav-link {
      color: #fff; /* Change the color of the navbar links */
    }

    .navbar-nav .nav-link:hover {
      color: #e50914; /* Change the color of the navbar links on hover */
    }

    .dropdown-menu {
      background-color: #333; /* Change the background color of the dropdown menu */
    }

    .dropdown-item {
      color: #fff; /* Change the color of the dropdown items */
    }

    .dropdown-item:hover {
      background-color: #e50914; /* Change the background color of the dropdown items on hover */
    }
  </style>
</head>
<body>

{{-- menubar --}}
<nav class="navbar navbar-expand-sm fixed-top">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Quantum IT Innovation</a>

  <!-- Links -->
  <ul class="navbar-nav">
    
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Menu
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/company">Create Company</a>
        <a class="dropdown-item" href="/add-company">View Company</a>
        <a class="dropdown-item" href="/employee">Create Employees</a>
        <a class="dropdown-item" href="/add-employee">View Employees</a>
      </div>
    </li>
  </ul>
</nav>
<br>

        
      <div class="container">
      </div>
      {{-- menubar  --}} 


<div class="container">
    <table class="table table-bordered shadow text-center table-striped">
        <h3 class="text-center"><font >View Company Record</font></h3>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Logo</th>
          <th>Website</th>
          <th>Edit</th>
          <th>Delete</th>
      </tr>
      @foreach ($companies as $company)
      <tr>
          <td>{{$company->id}}</td>
          <td>{{$company->name}}</td>
          <td>{{$company->email}}</td>
          <td>
            <img src="{{ asset('/storage/company/' . $company->logo) }}" width="80px" height="60px" alt="Image">
          </td>

          <td>{{$company->website}}</td>
        
        <td><a href="/edit_company/{{$company->id}}" class="btn btn-info">Edit</a></td>
        <td><a href="/delete_company/{{$company->id}}" class="btn btn-danger">Delete</a></td>
        
              </tr>
        @endforeach
    </table>
    <a href="{{'company'}}" class="btn btn-success  text-center">Back</a>
  </div>
  
    <!-- Client Grid -->
</body>    
  <!-- Mirrored from demo.dashboardpack.com/architectui-html-pro/forms-controls.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jun 2023 13:13:49 GMT -->
  </html>
  
  
{{-- ****************************************Part-2{Form}******************************************************** --}}
