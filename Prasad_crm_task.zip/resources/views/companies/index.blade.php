<!DOCTYPE html>
<html>
<head>
  <title>Add a New Company</title>
  <!-- Include Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="companyindex.php">
  <style>
    /* Add any additional custom styles here if needed */
    body {
      margin: 0px;
      padding-top: 70px; /* Add padding to body to avoid content overlapping with the fixed navbar */
    }

    /* Customize the navbar appearance */
    .navbar {
      background-color: #333; /* Change the background color of the navbar */
      border-bottom: 3px solid #e50914; /* Add a bottom border with a red color */
    }

    .navbar-brand {
      color: #e50914; /* Change the color of the navbar brand text */
      font-weight: bold; /* Add bold font weight to the navbar brand text */
    }

    .navbar-nav .nav-link {
      color: #fff; /* Change the color of the navbar links */
    }

    .navbar-nav .nav-link:hover {
      color: #e50914; /* Change the color of the navbar links on hover */
    }

    .dropdown-menu {
      background-color: #333; /* Change the background color of the dropdown menu */
    }

    .dropdown-item {
      color: #fff; /* Change the color of the dropdown items */
    }

    .dropdown-item:hover {
      background-color: #e50914; /* Change the background color of the dropdown items on hover */
    }
  </style>
</head>
<body>

{{-- menubar --}}
<nav class="navbar navbar-expand-sm fixed-top">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Quantum IT Innovation</a>

  <!-- Links -->
  <ul class="navbar-nav">
    
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Menu
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/company">Create Company</a>
        <a class="dropdown-item" href="/add-company">View Company</a>
        <a class="dropdown-item" href="/employee">Create Employees</a>
        <a class="dropdown-item" href="/add-employee">View Employees</a>
      </div>
    </li>
  </ul>
</nav>
<br>

{{-- ****************************************Part-2{Form}******************************************************** --}}

<div class="container">
  <div class="row">
  <div class="col-md-12">
      <div class="col-md-12">
          <div class="col-md-12">

              @if(session('status'))
                  <h6 class="alert alert-success">{{session('status')}}</h6>
              @endif     
          
          </h4>
          
      <div class="card-body">
            
      <div class="container">
      <h2>Add a New Company</h2>
      <form action="{{'add-company'}}" method="post" enctype="multipart/form-data">
        @csrf
    {{-- <form action="/companies/store" method="get" enctype="multipart/form-data"> --}}
      <div class="form-group">
        <label for="name">Company Name :<span style="color: red;">*</span></label>
        <input type="text" class="form-control" id="name" name="name" required>
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" id="email" name="email">
      </div>
      <div class="form-group">
        <label>Logo:<span style="color: red;">*</span></label>
        <div class="custom-file">
          <input type="file" class="custom-file-input" id="logo" name="logo" required>
          <label class="custom-file-label" for="logo">Choose Logo (Minimum size: 100x100)</label>
        </div>
      </div>
      <div class="form-group">
        <label for="website">Website:</label>
        <input type="text" class="form-control" id="website" name="website">
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-primary">Add Company</button>
        <a href="{{url('add-company')}}" class="btn btn-success float-end">View Company</a>
      </div>
    </form>
  </div>

</div>
</div>
</div>           
</div>
</div>
</div>

  <!-- Include Bootstrap JS and jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>


  
{{-- ****************************************Part-2{Form}******************************************************** --}}
