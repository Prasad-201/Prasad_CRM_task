<!DOCTYPE html>
<html>
<head>
  <title>Dashboard</title>
  <!-- Include Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    /* Add any additional custom styles here if needed */
    body {
      margin: 0px;
      padding-top: 70px; /* Add padding to body to avoid content overlapping with the fixed navbar */
      margin: 0;
 
  background-image: url('https://png.pngtree.com/thumb_back/fh260/background/20201026/pngtree-scene-with-geometrical-forms-the-poster-model-minimal-background-render-image_437743.jpg');
  background-size: cover;
  background-repeat: no-repeat;
    }

    /* Customize the navbar appearance */
    .navbar {
      background-color: #333; /* Change the background color of the navbar */
      border-bottom: 3px solid #e50914; /* Add a bottom border with a red color */
    }

    .navbar-brand {
      color: #e50914; /* Change the color of the navbar brand text */
      font-weight: bold; /* Add bold font weight to the navbar brand text */
    }

    .navbar-nav .nav-link {
      color: #fff; /* Change the color of the navbar links */
    }

    .navbar-nav .nav-link:hover {
      color: #e50914; /* Change the color of the navbar links on hover */
    }

    .dropdown-menu {
      background-color: #333; /* Change the background color of the dropdown menu */
    }

    .dropdown-item {
      color: #fff; /* Change the color of the dropdown items */
    }

    .dropdown-item:hover {
      background-color: #e50914; /* Change the background color of the dropdown items on hover */
    }
  </style>
</head>
<body>

{{-- menubar --}}
<nav class="navbar navbar-expand-sm fixed-top">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Quantum IT Innovation</a>

  <!-- Links -->
  <ul class="navbar-nav">
    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Menu
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="/company">Create Company</a>
        <a class="dropdown-item" href="/add-company">View Company</a>
        <a class="dropdown-item" href="/employee">Create Employees</a>
        <a class="dropdown-item" href="/add-employee">View Employees</a>
      </div>
    </li>
  </ul>
</nav>
<br>

    

<div class="container">
 </div>
{{-- menubar  --}} 

<!-- Include Bootstrap JS and jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>










