<!DOCTYPE html>
<html>
<head>
  <title>Add a New Company</title>
  <!-- Include Bootstrap CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="companyindex.php">
  <style>
    /* Add any additional custom styles here if needed */
    body {
      *margin: 0px;
    }
  </style>
</head>
<body>

{{--********************************************** menubar *************************************--}}
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Quantum IT Innovation</a>

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="#">Create Comapny</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">View Comapnies</a>
    </li>

    <!-- Dropdown -->
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
        Menu
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="companies\index.blade.php">Create Company</a>
        <a class="dropdown-item" href="#">View Comapny</a>
        <a class="dropdown-item" href="#">Create Employees</a>
        <a class="dropdown-item" href="#">View Employees</a>
      </div>
    </li>
  </ul>
</nav>
<br>
  
{{-- ****************************************Part-2{Form}******************************************************** --}}
<div class="container">
    <div class="row">
    <div class="col-md-12">
        <div class="col-md-12">
            <div class="col-md-12">

            
            <a href="{{url('add-employee')}}" class="btn btn-primary float-end">Add Student</a>
            </h4>
            
            <div class="card-body">
              <table class="table table-bordered shadow text-center table-striped">
                <h3 class="text-center"><font >View Company Record</font></h3>
                <tr>
        
                    <th>Name</th>
                    <th>Email</th>
                    <th>Logo</th>
                    <th>Website</th>
                    <th>Edit</th>
                </tr>
                @foreach ($students as $student)
                <tr>
                    <td>{{$student->id}}</td>
                    <td>{{$student->name}}</td>
                    <td>{{$student->email}}</td>

                    <td>
                      <img src="{{ asset('storage/company_img/' . $student->image) }}" width="80px" height="60px" alt="Image">
                     
                    </td>

                    <td>{{$student->course}}</td>

                    <td><a href="/edit/{{$student->id}}" class="btn btn-info">Edit</a></td>
                    <td><a href="/edit/{{$student->id}}" class="btn btn-danger">Delete</a></td>
                </tr>
                @endforeach
            </table>
            </div>
</div>
 </div>           
</div>
</div>
</div>




  <!-- Include Bootstrap JS and jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
