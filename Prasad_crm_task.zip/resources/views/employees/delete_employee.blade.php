<!DOCTYPE html>
<html>
<head>
    <title>Delete Employee</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Add any additional custom styles here if needed */
        body {
            margin: 20px;
        }
    </style>
</head>

<body>
<div class="container">
    <h2>Delete Employee</h2>
    <p>Are you sure you want to delete this employee?</p>
    <form action="/delete/{id}" method="get">
        @csrf
        <button type="submit" class="btn btn-danger">Delete</button>
        <a href="/view-employees" class="btn btn-secondary
    </form>
</div>
</html>